/*
 * Plaque.c
 *
 * INF147 - TP2
 *
 * Created on: 2025-02-27
 * Author: Ilyes Gharmoul
 *
 * Description: Ce fichier contient des fonctions pour manipuler et évaluer un puzzle coulissant (plaque) pour le cours INF147.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "main.h"
#include "Plaque.h"
#include <stdlib.h>

void trouver_Valeur(const t_plaque pla, int val, int *py_val, int *px_val)
{
    for (int y = 0; y < DIM; y++)
    {
        for (int x = 0; x < DIM; x++)
        {
            if (pla[x][y] == val)
            {
                *py_val = y;
                *px_val = x;
            }
        }
    }
}

int changer_plaque(t_plaque pla, t_direction dir, int *py_0, int *px_0)
{
    int tempt;
    int new_x = *px_0; // 0x
    int new_y = *py_0; // 0y
    switch (dir)
    {
    case HAUT:
        new_x--; //-1x
        break;
    case BAS:
        new_x++;
        break;
    case GAUCHE:
        new_y--;
        break;
    case DROITE:
        new_y++;
        break;
    default:
        return 0;
        break;
    }
    if (new_x >= 0 && new_x < DIM && new_y >= 0 && new_y < DIM) // function fail -1x
    {
        tempt = pla[*px_0][*py_0];
        pla[*px_0][*py_0] = pla[new_x][new_y];
        pla[new_x][new_y] = tempt;
        *px_0 = new_x;
        *py_0 = new_y;
        return 1;
    }
    return 0;
}

void melanger_plaque(t_plaque pla, int *py_0, int *px_0)
{
#ifdef DEBUG1
    trouver_Valeur(pla, VIDE, py_0, px_0);
    printf("Valeur trouvee de %d a la case: y=%d, x=%d\n", VIDE, *py_0 + 1, *px_0 + 1);
#endif
    for (int i = 0; i < NBCOUPS; i++)
    {
        int direction = rand() % (DROITE + 1); // 0 is left, 1 is right, 2 is up, 3 is down
#ifdef DEBUG1
        printf("Direction:");
        switch (direction)
        {
        case GAUCHE:
            printf("GAUCHE\n");
            break;
        case DROITE:
            printf("DROITE\n");
            break;
        case HAUT:
            printf("HAUT\n");
            break;
        case BAS:
            printf("BAS\n");
            break;
        default:
            break;
        }
#endif
        trouver_Valeur(pla, VIDE, py_0, px_0);
#ifdef DEBUG1
        printf("y=%d,x=%d of VIDE\n", *px_0 + 1, *py_0 + 1);
#endif
        changer_plaque(pla, direction, py_0, px_0);

#ifdef DEBUG1
        printf("y=%d,x=%d of VIDE after change\n", *px_0 + 1, *py_0 + 1);
        afficher_plaque(pla);
#endif
    }
}
int evaluer_plaque(const t_plaque pla)
{
    int cost = 0;
    int x_solution, y_solution;
    int x_current, y_current;
    for (int num = 0; num < DIM * DIM; num++)
    {
        trouver_Valeur(pla, num, &y_current, &x_current);
        trouver_Valeur(SOLUTION, num, &y_solution, &x_solution);
        cost += abs(x_current - x_solution) + abs(y_current - y_solution);
        x_current = 0;
        y_current = 0;
    }
    return cost;
}

void afficher_plaque(const t_plaque pla)
{
#ifdef DEBUG

#endif
    case_Graphique();
    for (int i = 0; i < DIM; i++)
    {
        for (int j = 0; j < DIM; j++)
        {
            printf("|%X|", pla[i][j]);
        }
        case_Graphique();
    }
}

void case_Graphique(void)
{
    printf("\n");
    for (int i = 0; i < DIM; i++)
        printf("---");
    printf("\n");
}
