/**
 * @file main.c
 * @brief Implémentation du jeu de puzzle glissant et de ses fonctionnalités associées.
 *
 * Objectif :
 * L'objectif est de pratiquer la programmation modulaire en développant un projet divisé en plusieurs fichiers de bibliothèque.
 * Ce projet permettra également aux étudiants de pratiquer les structures de données avancées et les concepts de base de l'intelligence artificielle.
 *
 * Description :
 * Le puzzle glissant (ou "Taquin") est un jeu de puzzle classique joué sur une grille NxN où N^2-1 cases contiennent des numéros et une case est laissée vide.
 * L'objectif est de déplacer la case vide en faisant glisser un numéro voisin (horizontalement ou verticalement) jusqu'à ce que tous les numéros soient dans leur configuration finale appelée l'état "solution".
 *
 * Ce fichier contient la fonction principale et les fonctions de test pour le jeu de puzzle glissant.
 * La fonction principale initialise le jeu et exécute les fonctions de test appropriées en fonction des macros définies.
 *
 * Tests partie 1:
 * Le code inclut diverses fonctions de test pour vérifier la correction des fonctionnalités implémentées.
 * Ces tests incluent :
 * - Trouver la valeur dans la grille
 * - Mélanger la grille
 * - Évaluer la grille
 * - Changer la grille en fonction de l'entrée utilisateur
 * - Opérations de pile pour gérer les mouvements
 *
 * Les tests peuvent être exécutés en définissant les macros appropriées (par exemple, DEBUG, TP2_1, TP2_2) de main.h et en exécutant le programme.
 *
 * Utilisation :
 * Compiler et exécuter le programme avec la configuration souhaitée pour tester les fonctionnalités.
 * Le programme affichera la grille et permettra à l'utilisateur d'interagir avec elle à l'aide des touches fléchées.
 * Appuyer sur la touche Échap passera à la phase de test, où diverses fonctions seront testées et leurs résultats affichés.
 *
 *
 * @date 2025-03-01
 * @version 1.0
 * Test partie 2
 * Le code inclut diverses fonctions de test pour vérifier la correction des fonctionnalités implémentées.
 * Ces tests incluent :
 * - Initialisation de la pile
 * - Libération de la pile
 * - Obtenir le nombre d'éléments dans la pile
 * - Vérifier si la pile est pleine
 * - Vérifier si la pile est vide
 * - Retirer un élément de la pile
 */

#include "main.h"

#ifdef DEBUG
#ifdef TP2_1
int x;
int y;
int search = 2;
int main_debug1()
{
#ifdef T_EVALUER_PLAQUE
    t_plaque test = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}};
    afficher_plaque(SOLUTION);
    afficher_plaque(test);
    printf("Eval: %d\n", evaluer_plaque(test));

    melanger_plaque(test, &y, &x);
    afficher_plaque(SOLUTION);
    afficher_plaque(test);
    printf("Eval: %d\n", evaluer_plaque(test));
#endif
#ifdef T_CHANGER_PLAQUE
    t_plaque test = {{8, 3, 4}, {1, 2, 5}, {6, 7, 0}};
    afficher_plaque(test);
    melanger_plaque(test, &y, &x);
    return 0;
#endif
#ifdef T_TROUVER_VALEUR
    t_plaque test = {{8, 3, 4}, {1, 2, 5}, {6, 7, 0}};
    afficher_plaque(test);
    trouver_Valeur(test, search, &y, &x);
    printf("Valeur trouvee de %d a la case: y=%d, x=%d\n", search, y + 1, x + 1);
#endif
    return 0;
#ifdef T_ARROW_KEY
    printf("Direction: %d\n", DirectionInput());
    return 0;
#endif
    return 0;
}
int main_init(void)
{
    srand(time(NULL));
    return 0;
}
#endif
#ifdef TP2_2

int main_debug2()
{
#ifdef T_PILE_CREATE
    printf("Test de la pile\n");
    t_pile test = creer_pile(MAXNOEUDS);
    printf("La pile est pleine: %d\n", pile_pleine(&test));
    printf("La pile est vide: %d\nPushing...\n", pile_vide(&test));
    push_pile(&test, elem);
    printf("Le nombre d'elements dans la pile est: %d\n", get_nb_elements(&test));
    printf("La pile est pleine: %d\n", pile_pleine(&test));
    printf("La pile est vide: %d\n", pile_vide(&test));
    for (int i = 0; i < 10; i++)
    {
        melanger_plaque(elem.plaque, &elem.posy_0, &elem.posx_0);
        elem.cout = evaluer_plaque(elem.plaque);
        push_pile(&test, elem);
        afficher_plaque(test.items[i].plaque);
        printf("Cout = %d\n", test.items[i].cout);
        printf("Le nombre d'elements dans la pile est: %d\n", get_nb_elements(&test));
    }
    printf("La pile est pleine: %d\n", pile_pleine(&test));
    printf("La pile est vide: %d\n", pile_vide(&test));
    liberer_pile(&test);
#endif
#ifdef T_ALGO_FINDSOLUTION
    t_liste_noeuds liste_noeuds;
    t_tab_ptr_niveaux niveaux;
    t_element elem = {{{1, 2, 3}, {4, 5, 6}, {7, 8, 0}}, 0, 0, 0, 0, 0, NULLE};
    int pos_solution = -1;
    initialiser_arbre(elem.plaque, elem.posy_0, elem.posx_0, liste_noeuds, niveaux);
    printf("Test algo: chercher une solution\n");
    int trouve = 0, nb_iterations = 0, posfin;

    // Initialize plaque_depart to a shuffled configuration
    memcpy(elem.plaque, SOLUTION, sizeof(t_plaque));
    //melanger_plaque(elem.plaque, &elem.posy_0, &elem.posx_0);

    printf("Plaque de départ mélangée:\n");
    afficher_plaque(elem.plaque);
    printf("Cout initial: %d\n", evaluer_plaque(elem.plaque));

    elem.cout = evaluer_plaque(elem.plaque);

    while (!trouve) {
        initialiser_arbre(elem.plaque, elem.posy_0, elem.posx_0, liste_noeuds, niveaux);
        printf("Essai avec MAXCOUT = %d\n", elem.cout);

        if (trouver_solution(liste_noeuds, niveaux, elem.cout, &posfin)) {
            afficher_solution(liste_noeuds, posfin);
            trouve = 1;
        } else {
            nb_iterations++;
        }
    }

    printf("\nCout initial: %d\n", evaluer_plaque(elem.plaque));
    printf("Cout final: %d\n", elem.cout);
    printf("Nombre d'iterations: %d\n", nb_iterations);
    getchar();
    return 0;

#endif
#ifdef T_ALGO_INIT
t_pile algo = creer_pile(MAXNOEUDS);
push_pile(&algo, elem);
afficher_plaque(algo.items[0].plaque);
printf("Cout = %d\n", algo.items[0].cout);
liberer_pile(&algo);
#endif
#ifdef T_ALGO_ONEDEEPNESS
int posfin = -1;
printf("Test algo: chercher une profondeur\n");
int max_cout = liste_noeuds[0].cout;
t_pile algo = creer_pile(MAXNOEUDS);
push_pile(&algo, liste_noeuds[0]);
if (!pile_vide(&algo))
{
    printf("pile non vide\n");
    for (int j = 1; j < sizeof(t_direction) + 1; j++)
    {
        liste_noeuds[j] = liste_noeuds[0];
        liste_noeuds[j].dir = j - 1;
        changer_plaque(liste_noeuds[j].plaque, liste_noeuds[j].dir, &liste_noeuds[j].posy_0, &liste_noeuds[j].posx_0);
        liste_noeuds[j].cout = evaluer_plaque(liste_noeuds[j].plaque);
        if (liste_noeuds[j].cout == 0)
            liste_noeuds[j].terminal = 1;
        else
            liste_noeuds[j].terminal = 0;
        niveaux[j] = niveaux[0] + 1;
    }
    int posfin = 1;
    for (int j = 2; j < sizeof(t_direction) + 1; j++)
    {
        if (liste_noeuds[j].cout > max_cout)
        {
            push_pile(&algo, liste_noeuds[j]);
            posfin = j;
        }
    }
}
for (int i = 1; i < 5; i++)
{
    afficher_plaque(liste_noeuds[i].plaque);
    printf("Tableau: %d\n", i);
    printf("Cout = %d\n", liste_noeuds[i].cout);
    switch (liste_noeuds[i].dir)
    {
    case GAUCHE:
        printf("Gauche\n");
        break;
    case DROITE:
        printf("Droite\n");
        break;
    case HAUT:
        printf("Haut\n");
        break;
    case BAS:
        printf("Bas\n");
        break;
    default:
        break;
    }
}
printf("La posfin du cout le plus petit est:\n Tableau %d\n", posfin);
liberer_pile(&algo);
afficher_solution(liste_noeuds, posfin);
#endif

return 0;
}
#endif
#endif
#ifdef TP2_1
int x;
int y;
t_plaque T_2_1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 0}};

int main_TP2_1()
{
    for (;;)
    {
        trouver_Valeur(T_2_1, 0, &y, &x);
        int direction = SaisieDirection();
        if (direction == TOUCHE_ESC)
        {
            printf("\n Passage a la phase de test...\n\n\n================ PHASE DE TEST ================\n Test de la fonction trouver_valeur()\n");
            afficher_plaque(T_2_1);
            trouver_Valeur(T_2_1, 5, &y, &x);
            printf("Valeur trouvee de 5 a la case: y=%d, x=%d\n", y + 1, x + 1);
            printf("\n Test de la fonction melanger_plaque()\n");
            melanger_plaque(T_2_1, &y, &x);
            afficher_plaque(T_2_1);
            printf("Cout aprs melange = %d\n", evaluer_plaque(T_2_1));
            trouver_Valeur(T_2_1, 0, &y, &x);
            printf("Valeur trouvee de 0 a la case: y=%d, x=%d\n", y + 1, x + 1);

            printf("\n Test des tests\n");
            system("pause");
            return 0;
        }

        changer_plaque(T_2_1, direction, &y, &x);
        afficher_plaque(T_2_1);
        printf("Cout = %d\n", evaluer_plaque(T_2_1));
        printf("CASE VIDE: y=%d, x=%d\n", y + 1, x + 1);
    }
}
int main_init()
{
    srand(time(NULL));
    printf("Appuyer sur les fleches pour deplacer la case vide.\n");
    printf("Appuyer sur Echap pour quitter.\n");
    afficher_plaque(T_2_1);
    return 0;
}
#endif

#ifdef TP2_2
#include "Algorithme.h"
#include "pile.h"
int main_TP2_2()
{
    return 0;
}
int main_init()
{
    srand(time(NULL));
    return 0;
}
#endif

int main()
{
    main_init();
#ifdef DEBUG
#ifdef TP2_1
    return main_debug1();
#elif defined(TP2_2)
    return main_debug2();
#endif
#elif defined(TP2_1)
    return main_TP2_1();
#elif defined(TP2_2)
    return main_TP2_2();
#else
    printf("No configuration defined!\n");
    return 1; // Error code
#endif
}
