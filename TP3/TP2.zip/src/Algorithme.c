#include "Algorithme.h"
#include "pile.h"
#include <stdio.h>
#include <string.h>

// Fonction pour initialiser l'arbre
void initialiser_arbre(const t_plaque plaque_depart, int py_0, int px_0,
                       t_liste_noeuds liste_noeuds, t_tab_ptr_niveaux niveaux)
{
    liste_noeuds[0].posx_0 = px_0;
    liste_noeuds[0].posy_0 = py_0;
    liste_noeuds[0].cout = evaluer_plaque(plaque_depart);
    liste_noeuds[0].profondeur = 0;
    liste_noeuds[0].parent = -1;
    liste_noeuds[0].terminal = 0;
    liste_noeuds[0].dir = NULLE; // we should never have to take direction
    memcpy(liste_noeuds[0].plaque, plaque_depart, sizeof(t_plaque));
    // for (int i = 0; i < DIM; i++)
    //{
    //     for (int j = 0; j < DIM; j++)
    //         liste_noeuds[0].plaque[i][j] = plaque_depart[i][j];
    // }
    for (int i = 0; i < MAXNOEUDS; i++)
        niveaux[i] = -1;

    niveaux[0] = 0;
}
/**
 * Fonction pour trouver la solution
 *
 * @param liste_noeuds Liste des noeuds de l'arbre de recherche
 * @param niveaux Tableau des niveaux de l'arbre de recherche
 * @param max_cout Coût maximum autorisé pour la recherche
 * @param posfin Pointeur vers la position finale de la solution trouvée
 * @return 1 si une solution est trouvée, 0 sinon
 */
int trouver_solution(t_liste_noeuds liste_noeuds, t_tab_ptr_niveaux niveaux,
    int max_cout, int* posfin)
{
    // max = 22?
    int last_terminal = 0;
    static int posParent = 0;
    int min_cout = liste_noeuds[0].cout;
    while(last_terminal == 0 && posParent < MAXNOEUDS)
    {
        t_pile nouvelleliste;
        t_coup parent = liste_noeuds[posParent];
        t_coup enfant[sizeof(t_direction)];
        t_direction inverse_dir;

        // Determine the inverse direction of the parent's move
        switch (parent.dir) {
            case HAUT: inverse_dir = BAS; break;
            case BAS: inverse_dir = HAUT; break;
            case GAUCHE: inverse_dir = DROITE; break;
            case DROITE: inverse_dir = GAUCHE; break;
            default: inverse_dir = NULLE; // This should never happen, except for root parent
        }
        for (int j = 0; j < sizeof(t_direction); j++)
        {
            enfant[j]=parent;
            enfant[j].dir = j;
            if (j == inverse_dir) continue;
            changer_plaque(enfant[j].plaque, enfant[j].dir, &enfant[j].posy_0, &enfant[j].posx_0);
            afficher_plaque(enfant[j].plaque);
            enfant[j].cout = evaluer_plaque(enfant[j].plaque);
            printf("Cout = %d\n", enfant[j].cout);
            enfant[j].profondeur = parent.profondeur + 1;
            enfant[j].parent = posParent;
           // getchar();
        }
        for (int j = 0; j < sizeof(t_direction); j++)
        {
            if(enfant[j].cout < min_cout)
                enfant[j].terminal = 1;
            posParent++;
            liste_noeuds[posParent] = enfant[j];
        }
        if((enfant[0].terminal == 1)&&(enfant[1].terminal == 1)&&(enfant[2].terminal == 1)&&(enfant[3].terminal == 1))
        {
            last_terminal = 1;
            *posfin = posParent;
        }
    }
    return 0;
}

// Fonction pour afficher la solution
void afficher_solution(const t_liste_noeuds liste_noeuds, int posfin)
{
    t_pile pile = creer_pile(MAXNOEUDS);
    int current = posfin;
    while (current != -1 && liste_noeuds[current].dir != NULLE)
    {
        push_pile(&pile, liste_noeuds[current]);
        current = liste_noeuds[current].parent;
    }
    printf("\nSolution (en %d coups):\n", get_nb_elements(&pile));
    while (!pile_vide(&pile))
    {
        t_element dir;
        pop_pile(&pile, &dir);

        switch (dir.dir)
        {
        case HAUT: printf("HAUT "); break;
        case BAS: printf("BAS "); break;
        case GAUCHE: printf("GAUCHE "); break;
        case DROITE: printf("DROITE "); break;
        default: break;
        }
    }
    printf("\n");
    liberer_pile(&pile);
}