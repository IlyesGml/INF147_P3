/**
 * @file pile.c
 * @brief Implémentation des opérations de pile.
 *
 * Ce fichier contient l'implémentation des opérations de pile telles que push, pop et peek.
 * Il fournit une structure de données de pile simple pour les valeurs entières.
 *
 * @date 2025-02-18
 * @version 1.0
 */
#include "main.h"
#include "pile.h"
#include <stddef.h>

/**
 * @brief Crée une pile avec une taille spécifiée.
 *
 * @param taille Taille de la pile.
 * @return La pile créée.
 */
t_pile creer_pile(unsigned int taille)
{
    t_pile p = {0};
    p.items = (t_coup*)calloc(taille, sizeof(t_coup)); // Allocation dynamique d'un tableau de taille 'taille' et type 't_coup'
    if (!p.items) // Vérification de la réussite de l'allocation
    {
        // Allocation échouée, retourne une pile vide
        p.taille = 0;
        p.sommet = -1;
        return p;
    }
    p.taille = taille; // Si l'allocation a réussi, la taille de la pile est 'taille'
    p.sommet = -1; // Initialisation de l'indice du sommet à -1 pour indiquer que la pile est vide
    return p; // Retourne la pile créée
}

/**
 * @brief Libère la mémoire allouée pour la pile.
 *
 * @param pile Pointeur vers la pile.
 */
void liberer_pile(t_pile *pile)
{
    free(pile->items); // Libération de la mémoire allouée pour le tableau dynamique
}

/**
 * @brief Obtient le nombre d'éléments dans la pile.
 *
 * @param pile Pointeur vers la pile.
 * @return Nombre d'éléments dans la pile.
 */
unsigned int get_nb_elements(const t_pile *pile)
{
    return pile->sommet + 1; // Retourne le nombre d'éléments dans la pile
}

/**
 * @brief Vérifie si la pile est pleine.
 *
 * @param pile Pointeur vers la pile.
 * @return 1 si la pile est pleine, 0 sinon.
 */
int pile_pleine(const t_pile *pile)
{
    if (pile->sommet < pile->taille - 1)
        return 0;  
    return 1;  
}

/**
 * @brief Vérifie si la pile est vide.
 *
 * @param pile Pointeur vers la pile.
 * @return 1 si la pile est vide, 0 sinon.
 */
int pile_vide(const t_pile *pile)
{
    return (pile->sommet == -1); // Retourne 1 si la pile est vide, 0 sinon
}

/**
 * @brief Retire un élément de la pile.
 *
 * @param pile Pointeur vers la pile.
 * @param dest Pointeur vers l'élément retiré.
 * @return 1 si l'opération a réussi, 0 sinon.
 */
int pop_pile(t_pile *pile, t_element *dest)
{
    // Vérification que la pile et le pointeur de destination ne sont pas NULL
    if (!pile || !pile->items||!dest) {
        return 0;
    }
    // Vérifie si la pile n'est pas vide avant de retirer un élément
    if(pile->sommet>=0)
    {
        *dest = pile->items[pile->sommet]; // Copie l'élément au sommet de la pile dans le pointeur de destination
        pile->sommet--; // Décrémente l'indice du sommet
        return 1; // Indique que l'opération a réussi
    }
    return 0; 
}

/**
 * @brief Ajoute un élément à la pile.
 *
 * @param pile Pointeur vers la pile.
 * @param src Élément à ajouter à la pile.
 * @return 1 si l'ajout a réussi, 0 sinon.
 */
int push_pile(t_pile *pile, t_element src)
{
    // Vérification que la pile et le pointeur de destination ne sont pas NULL
    if (!pile || !pile->items) {
        return 0;
    }
    // Vérifie si la pile n'est pas pleine avant d'ajouter un nouvel élément
    if (pile->sommet < pile->taille - 1) {
        pile->sommet++; // Incrémente l'indice du sommet
        pile->items[pile->sommet] = src; // Stocke l'élément au sommet de la pile
        return 1; // Indique que l'ajout a réussi
    }
    // Si la pile est pleine, retourne 0 pour signaler l'échec de l'ajout
    return 0;
}
