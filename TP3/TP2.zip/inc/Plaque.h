/**
 * @file Plaque.h
 * @brief Header file for the game board operations.
 */

#ifndef PLAQUE_H
#define PLAQUE_H

#define DIM 3 ///< la largeur de la plaque (3x3 cases en tout)
#define VIDE 0 ///< la valeur de la case vide
#define NBCOUPS 200 ///< le nombre de coups à faire pour mélanger la plaque initiale

/**
 * @enum t_direction
 * @brief Type énuméré pour les 4 déplacements possibles NULLE = -1, HAUT, GAUCHE, BAS, DROITE
 */
typedef enum {NULLE = -1, HAUT, GAUCHE, BAS, DROITE} t_direction;

/**
 * @typedef t_plaque
 * @brief Type-tableau pour la plaque de jeu
 */
typedef int t_plaque[DIM][DIM];

/**
 * @var SOLUTION
 * @brief Constante qui illustre la plaque-solution à trouver
 */
static const t_plaque SOLUTION = {{1, 2, 3}, {4, 5, 6}, {7, 8, VIDE}};

/**
 * @brief Recherche la position (ligne et colonne) d'une valeur donnée val dans la plaque de jeu pla.
 * @param pla La plaque de jeu.
 * @param val La valeur à rechercher.
 * @param py_val Pointeur vers la variable qui recevra l'indice de la ligne où se trouve la valeur.
 * @param px_val Pointeur vers la variable qui recevra l'indice de la colonne où se trouve la valeur.
 * @note Cette fonction suppose que la valeur val est garantie d'exister dans la plaque.
 */
void trouver_Valeur(const t_plaque pla, int val, int* py_val, int* px_val);

/**
 * @brief Effectue un déplacement de la case vide dans la direction voulue si le déplacement est valide.
 * @param pla La plaque de jeu.
 * @param dir La direction du déplacement.
 * @param py_0 Pointeur vers la variable contenant l'indice de la ligne de la case vide.
 * @param px_0 Pointeur vers la variable contenant l'indice de la colonne de la case vide.
 * @return 1 si le déplacement est valide et effectué, 0 sinon.
 */
int changer_plaque(t_plaque pla, t_direction dir, int *py_0, int *px_0);

/**
 * @brief Mélange la plaque de jeu en effectuant un nombre de déplacements aléatoires de la case vide.
 * @param pla La plaque de jeu.
 * @param py_0 Pointeur vers la variable contenant l'indice de la ligne de la case vide.
 * @param px_0 Pointeur vers la variable contenant l'indice de la colonne de la case vide.
 */
void melanger_plaque(t_plaque pla, int *py_0, int *px_0);

/**
 * @brief Évalue le coût minimal estimé pour atteindre l'état-solution à partir de la plaque reçue en paramètre.
 * @param pla La plaque de jeu.
 * @return Le coût minimal estimé.
 * @note Utilise la fonction trouver_Valeur() pour retrouver la position actuelle d’une valeur donnée dans la plaque.
 */
int evaluer_plaque(const t_plaque pla);

/**
 * @brief Affiche la plaque de jeu à l'écran, DIM valeurs par ligne.
 * @param pla La plaque de jeu.
 */
void afficher_plaque(const t_plaque pla);

/// @brief Dessine une case graphique pour plaque
/// @param  Aucun paramètre
void case_Graphique(void);

#endif // PLAQUE_H