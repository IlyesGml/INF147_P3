/******************************************************/
/* T_PILE.H :  (*** donné aux élèves ***)             */
/*                                                    */
/* Librairie de gestion d'une pile de coups à jouer.  */
/* Permet d'inverser une liste de coups pour ainsi    */
/* afficher le chemin-solution dans le bon sens.      */
/******************************************************/
#ifndef T_PILE_H
#define T_PILE_H  
/* Structure de base des éléments (un coup à jouer) */


// Déclaration des types structurés
typedef struct {
   t_plaque plaque; // la plaque de jeu
   int posx_0, posy_0; // la position de la case vide
   int cout; // le « coût » de ce nœud, Cout(N) = P(N) + E(N)
   int profondeur; // la profondeur (ou niveau) dans l’arbre de jeu
   int parent; // position du nœud-parent de ce noeud
   int terminal; // soit 0 (non-Terminal) ou 1 (Terminal)
   t_direction dir; // la direction qui à été utilisée pour générer cette plaque
} t_coup;

typedef t_coup t_element;

/**
 * @brief Structure de la pile des coups.
 */
typedef struct {
   t_element * items;  /**< @brief tableau dynamique des coups */
   int sommet;         /**< @brief le "haut" de la pile (== -1 lorsque vide) */
   int taille;         /**< @brief taille totale de la pile (taille du tableau) */
} t_pile;


/*********************   PROTOTYPES DES FONCTIONS PUBLIQUES  ***************************/

/* On commence avec les accesseurs et mutateurs d'un "t_coup". */

/* Voici le constructeur */

/* Le constructeur reçoit une capacité maximale d'éléments.
   Retourne une pile vide de cette taille (ou NULL si manque de mémoire) */
t_pile creer_pile(unsigned int taille);


/* Puis voici le destructeur */

/* Fonction qui va libérer le tableau dynamique de la pile le pointeur
   de cette pile ne devra plus être utilisé avant d’être réinitialisé. */
void liberer_pile(t_pile * pile);


/* Puis viennent trois fonctions informatrices de l’état de la pile :*/

/* Obtenir le nombre d'éléments actuellement dans la pile reçue en paramètre. */
unsigned int get_nb_elements (const t_pile * pile);

/* Vérifie si la pile est actuellement pleine.
   Retour de 1 si elle est vide, 0 sinon. */
int pile_pleine(const t_pile * pile);

/* Vérifie si la pile est actuellement vide.
   Retour de 1 si elle est vide, 0 sinon. */
int pile_vide(const t_pile * pile);


/* Puis viennent deux fonctions mutatrices de l’état de la pile : */

/* Extraction de la pile (POP):
   Qui reçoit le handle d'une pile existante et la référence ou copier l'objet extrait.
   Retour de 0 si la pile est vide -- seul cas possible -- sinon 1. */
int pop_pile(t_pile * pile, t_element *dest);

// Pushes an element onto the stack represented by 'pile'.
// 
// Parameters:
//   - pile: A pointer to the stack structure.
//   - src: The element to be pushed onto the stack.
//
// Returns:
//   An integer indicating the success of the operation (0 for success).
int push_pile(t_pile * pile, t_element src);

#endif //#ifndef T_PILE_H