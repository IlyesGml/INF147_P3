/**
 * @ Author: Ilyes Gharmoul
 * @ Create Time: 2025-02-18 19:04:25
 * @ Modified by: Your name
 * @ Modified time: 2025-03-13 16:38:34
 * @ Description: idk
 */

 #ifndef MAIN_H
 #define MAIN_H
 /********************************  <   PARAMETRES  >    ********************************/


#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <conio.h>

#include "userinput.h"
#include "Plaque.h"
#include "pile.h"
#include "Algorithme.h"
int main();
int main_init(void); // fonction d'initialisation


 /********************************  <   TEST UNITAIRE  >    ********************************/
 /***********************  <   VERSION  >    ********************************/
#define DEBUG
// #define TP2_1
#define TP2_2
#ifndef DEBUG
//#define TP2_1
#ifndef TP2_1
#define TP2_2
#endif
#endif
/****************************************************************************/
#ifdef DEBUG
/****************************  <   DEBUG  >    ************************************/
 /***********************   <   TP2_1  >    ****************************/
#ifdef TP2_1
int main_debug1(void); // fonction de test en mode débogage
// #define T_EVALUER_PLAQUE
// #define T_CHANGER_PLAQUE
// #define T_TROUVER_VALEUR
// #define T_ARROW_KEY
#elif defined(TP2_2)
 /***********************   <   TP2_2  >    ****************************/
int main_debug2(void); // fonction de test en mode débogage
//#define T_PILE_CREATE
//#define T_ALGO_INIT
//#define T_ALGO_ONEDEEPNESS
#define T_ALGO_FINDSOLUTION

#endif
#endif
/**********************************************************************************/
#ifdef TP2_1
int main_TP2_1(void); // remise partie 1 TP2
#endif
#ifdef TP2_2
int main_TP2_2(void); // remise final TP2
#endif

#endif