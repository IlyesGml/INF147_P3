#ifndef ALGORITHME_H
#define ALGORITHME_H
#include "main.h"
#define MAXNOEUDS 1000 // le nombre maximal de nœuds dans la liste


typedef t_coup t_liste_noeuds[MAXNOEUDS]; // type-tableau pour la liste des noeuds
typedef int t_tab_ptr_niveaux[MAXNOEUDS]; // type-tableau pour les niveaux

// Prototypes des fonctions

/**
 * @brief Initialise la structure de données pour la recherche.
 * 
 * @param plaque_depart La plaque de départ.
 * @param py_0 La position y de la case vide.
 * @param px_0 La position x de la case vide.
 * @param liste_noeuds La liste des nœuds à initialiser.
 * @param niveaux La liste des pointeurs de niveaux à initialiser.
 */
void initialiser_arbre(const t_plaque plaque_depart, int py_0, int px_0,
                       t_liste_noeuds liste_noeuds, t_tab_ptr_niveaux niveaux);

/**
 * @brief Effectue une passe de la recherche jusqu'à une profondeur de max_cout.
 * 
 * @param liste_noeuds La liste des nœuds.
 * @param niveaux La liste des pointeurs de niveaux.
 * @param max_cout La valeur maximale du coût pour la recherche.
 * @param posfin La position du nœud-solution dans la liste (si trouvé).
 * @return int 1 si la solution est trouvée, sinon 0.
 */
int trouver_solution(t_liste_noeuds liste_noeuds, t_tab_ptr_niveaux niveaux,
                     int max_cout, int *posfin);

/**
 * @brief Affiche tous les déplacements à faire de la plaque-départ jusqu'à la plaque-solution.
 * 
 * @param liste_noeuds La liste des nœuds.
 * @param posfin La position du nœud-solution dans la liste.
 */
void afficher_solution(const t_liste_noeuds liste_noeuds, int posfin);

#endif // ALGORITHME_H